package com.JKS.TIL1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Til1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
