package com.JKS.TIL1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Til1Application {

	public static void main(String[] args) {
		SpringApplication.run(Til1Application.class, args);
	}

}
